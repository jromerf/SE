/*****************************************************************************
* Filename:          U:\hlocal\SE-main\motor/drivers/motor_v1_00_a/src/motor.c
* Version:           1.00.a
* Description:       motor Driver Source File
* Date:              Tue Feb 23 17:56:04 2021 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "motor.h"

/************************** Function Definitions ***************************/

